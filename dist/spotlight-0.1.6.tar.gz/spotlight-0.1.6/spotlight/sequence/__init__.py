"""
Module for building recommender models that use sequences of
users' interactions to represent them.
"""
